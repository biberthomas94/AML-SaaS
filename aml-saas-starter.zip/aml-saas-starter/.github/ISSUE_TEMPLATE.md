## Goal
<Plain-English outcome you want (business/compliance terms)>

## Acceptance Criteria
- [ ] <Measurable condition 1>
- [ ] <Measurable condition 2>
- [ ] <Screenshots/tests included>

## Agent Prompt
“<Short directive that an AI agent can follow to implement this>”

## Labels
<e.g., infra, kyc, monitoring, cases, sar, audit, ui, demo>

## Notes
- Context, links, examples, or file attachments here.
